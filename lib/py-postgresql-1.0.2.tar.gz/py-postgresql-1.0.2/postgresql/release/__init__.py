##
# .release
##
"""
Release management code and project meta-data.
"""
