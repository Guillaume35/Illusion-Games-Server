"""
Modules and packages resolved to avoid user dependency resolution.
"""
